If it doesn't start for you, try running it several times until it works. 

Even if this does not help, use another program from the link -

-------------------------------------------------
https://www.mediafire.com/file/o9veb6xetbxw7fm/     | File password - 123
-------------------------------------------------
